//
//  ManagerCustomer.swift
//  EmptyApp
//
//  Created by Yining Chen on 10/28/21.
//  Copyright © 2021 rab. All rights reserved.
//

import Foundation
final class CustomerManager{
    public let testcustomerlist = CustomerDirecrtory(customerList: Array())
    
}
